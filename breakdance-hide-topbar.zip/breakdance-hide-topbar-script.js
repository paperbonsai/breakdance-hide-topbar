$(() => {
  const winParent = window.parent;
  const loadScript = () => {
    const script = winParent.document.createElement("script");
    script.src = "https://code.jquery.com/jquery-3.7.1.slim.min.js";
    script.type = "text/javascript";
    script.onload = init;
    winParent.document.head.appendChild(script);
  };

  const init = () => {
    if (winParent.jQuery) {
      const _$ = winParent.jQuery;

      const addNewElement = () => {
        if (!_$("body").find("#close_left_sidebar").length) {
          const newElement = _$(
            '<div id="close_left_sidebar" class="breakdance-panel-header-close-button breakdance-toolbar-icon-button breakdance-toolbar-icon-button-small-button" style="margin-right: 6px;"><div class="breakdance-icon" style="width: 16px; height: 16px;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M312.1 375c9.369 9.369 9.369 24.57 0 33.94s-24.57 9.369-33.94 0L160 289.9l-119 119c-9.369 9.369-24.57 9.369-33.94 0s-9.369-24.57 0-33.94L126.1 256 7.027 136.1c-9.369-9.369-9.369-24.57 0-33.94s24.57-9.369 33.94 0L160 222.1l119-119c9.369-9.369 24.57-9.369 33.94 0s9.369 24.57 0 33.94L193.9 256l118.2 119z"></path></svg></div></div>'
          ).on("click", () =>
            _$(".breakdance-app-left-area").css("display", "none")
          );
          _$(".properties-panel-duplicate-button").before(newElement);
        }
      };

      const toggleHeight = () => {
        const isVisible = _$(".breakdance-top-bar-wrapper").is(":visible");
        _$(".breakdance-app-body-wrapper").css(
          "max-height",
          isVisible ? "calc(100vh - 55px)" : "100vh"
        );
      };

      $(document)
        .add(_$(".breakdance-add-panel"))
        .on("click", () => {
          addNewElement();
          _$(".breakdance-app-left-area").show();
        });

      _$(".open-elements-toolbar-button, .open-structure-toolbar-button")
        .on("click", function () {
          _$(this).next(".left-area, .right-area");
        })
        .click();

      const n = $("<button>", {
        type: "button",
        class: "open-structure-toolbar-button breakdance-toolbar-icon-button",
        css: {
          margin: "0 10px",
          paddingTop: "3px",
        },
        html: `
        <span class="v-btn__content">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
                <svg clip-rule="evenodd" fill-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="m11.998 5c-4.078 0-7.742 3.093-9.853 6.483-.096.159-.145.338-.145.517s.048.358.144.517c2.112 3.39 5.776 6.483 9.854 6.483 4.143 0 7.796-3.09 9.864-6.493.092-.156.138-.332.138-.507s-.046-.351-.138-.507c-2.068-3.403-5.721-6.493-9.864-6.493zm8.413 7c-1.837 2.878-4.897 5.5-8.413 5.5-3.465 0-6.532-2.632-8.404-5.5 1.871-2.868 4.939-5.5 8.404-5.5 3.518 0 6.579 2.624 8.413 5.5zm-8.411-4c2.208 0 4 1.792 4 4s-1.792 4-4 4-4-1.792-4-4 1.792-4 4-4zm0 1.5c-1.38 0-2.5 1.12-2.5 2.5s1.12 2.5 2.5 2.5 2.5-1.12 2.5-2.5-1.12-2.5-2.5-2.5z" fill="#93C5FD"/>
                </svg>
                </svg>
        </span>
        `,
      });

      const o = $("<button>", {
        type: "button",
        class:
          "open-structure-toolbar-button breakdance-toolbar-icon-button breakdance-toolbar-icon-button-active",
        css: {
          position: "fixed",
          zIndex: "9999",
          top: "8px",
          right: "333px",
          backgroundColor: "transparent",
          transform: "translateX(-50%)",
        },
        html: `
        <span class="v-btn__content">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24">
                <svg clip-rule="evenodd" fill-rule="evenodd" stroke-linejoin="round" stroke-miterlimit="2" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="m17.069 6.546 2.684-2.359c.143-.125.32-.187.497-.187.418 0 .75.34.75.75 0 .207-.086.414-.254.562l-16.5 14.501c-.142.126-.319.187-.496.187-.415 0-.75-.334-.75-.75 0-.207.086-.414.253-.562l2.438-2.143c-1.414-1.132-2.627-2.552-3.547-4.028-.096-.159-.144-.338-.144-.517s.049-.358.145-.517c2.111-3.39 5.775-6.483 9.853-6.483 1.815 0 3.536.593 5.071 1.546zm2.319 1.83c.966.943 1.803 2.014 2.474 3.117.092.156.138.332.138.507s-.046.351-.138.507c-2.068 3.403-5.721 6.493-9.864 6.493-1.297 0-2.553-.313-3.729-.849l1.247-1.096c.795.285 1.626.445 2.482.445 3.516 0 6.576-2.622 8.413-5.5-.595-.932-1.318-1.838-2.145-2.637zm-3.434 3.019c.03.197.046.399.046.605 0 2.208-1.792 4-4 4-.384 0-.756-.054-1.107-.156l1.58-1.389c.895-.171 1.621-.821 1.901-1.671zm-.058-3.818c-1.197-.67-2.512-1.077-3.898-1.077-3.465 0-6.533 2.632-8.404 5.5.853 1.308 1.955 2.567 3.231 3.549l1.728-1.519c-.351-.595-.553-1.289-.553-2.03 0-2.208 1.792-4 4-4 .925 0 1.777.315 2.455.843zm-2.6 2.285c-.378-.23-.822-.362-1.296-.362-1.38 0-2.5 1.12-2.5 2.5 0 .36.076.701.213 1.011z" fill="#93C5FD"/>
                </svg>
                </svg>
        </span>
        `,
      }).on("click", () => {
        _$(".breakdance-top-bar-wrapper").toggle();
        _$(o).hide();
        toggleHeight();
      });

      n.on("click", () => {
        _$(".breakdance-top-bar-wrapper").toggle();
        _$("body").before(o).css("top", "100px");
        _$(o).show();
        toggleHeight();
      });

      _$(".undo-redo-top-bar-section.topbar-section.topbar-section-bl").before(
        n
      );
    } else setTimeout(init, 50);
  };

  winParent.jQuery ? init() : loadScript();
});
