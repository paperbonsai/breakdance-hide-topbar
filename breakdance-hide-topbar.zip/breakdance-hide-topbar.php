<?php
/*
 * Plugin Name: Breakdance - Hide Topbar & Always Show Sidebars
 * Plugin URI: https://codestormer.com
 * Description: A plugin to toggle the visibility of the top bar and ensure consistent sidebar display.
 * Version: 1.4
 * Author: Codestormer.com
 * Author URI: https://codestormer.com
 */

function bd_add_options_page()
{
    add_options_page(
        __('Breakdance Options', 'breakdance-hide-topbar'),
        __('Breakdance sidebars', 'breakdance-hide-topbar'),
        'manage_options',
        'breakdance-options',
        'bd_render_options_page'
    );
}
add_action('admin_menu', 'bd_add_options_page');

function bd_render_options_page()
{
?>
    <div class="wrap">
        <h1><?php _e('Breakdance Options', 'breakdance-hide-topbar'); ?></h1>
        <form action="options.php" method="post">
            <?php
            settings_fields('bd_options_group');
            do_settings_sections('breakdance-options');
            submit_button();
            ?>
        </form>
    </div>
<?php
}

function bd_add_settings_link($links)
{
    $settings_link = '<a href="options-general.php?page=breakdance-options">' . __('Settings', 'breakdance-hide-topbar') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}
$plugin = plugin_basename(__FILE__);
add_filter("plugin_action_links_$plugin", 'bd_add_settings_link');

function bd_register_settings()
{
    register_setting('bd_options_group', 'bd_options');

    add_settings_section(
        'bd_main_section',
        __('Main Settings', 'breakdance-hide-topbar'),
        'bd_render_main_section',
        'breakdance-options'
    );

    add_settings_field(
        'bd_load_sidebar',
        __('Always Display Sidebars', 'breakdance-hide-topbar'),
        'bd_render_load_sidebar_field',
        'breakdance-options',
        'bd_main_section'
    );
}
add_action('admin_init', 'bd_register_settings');

function bd_render_main_section()
{
    echo '<p>' . __('Configure the Breakdance plugin:', 'breakdance-hide-topbar') . '</p>';
}

function bd_render_load_sidebar_field()
{
    $options = get_option('bd_options');
    $checked = isset($options['load_sidebar']) ? 'checked' : '';
    echo '<input type="checkbox" name="bd_options[load_sidebar]" value="1" ' . $checked . '>';
}

function bd_get_all_plugins()
{
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    return get_plugins();
}

function bd_is_plugin_installed($plugin_name)
{
    $all_plugins = bd_get_all_plugins();
    foreach ($all_plugins as $plugin_data) {
        if ($plugin_data['Name'] == $plugin_name) return true;
    }
    return false;
}

function bd_is_plugin_active_by_name($plugin_name)
{
    $all_plugins = bd_get_all_plugins();
    foreach ($all_plugins as $plugin_path => $plugin_data) {
        if ($plugin_data['Name'] == $plugin_name && is_plugin_active($plugin_path)) return true;
    }
    return false;
}

function bd_breakdance_plugin_required_notice()
{
    if (is_admin() && (!bd_is_plugin_installed('Breakdance') || !bd_is_plugin_active_by_name('Breakdance'))) {
        echo '<div class="notice notice-error is-dismissible"><p>' . __('The required plugin Breakdance is not installed or activated. Please install and activate it to continue.', 'breakdance-hide-topbar') . '</p></div>';
    }
}
add_action('admin_notices', 'bd_breakdance_plugin_required_notice');

function bd_add_jquery_and_custom_script_to_head()
{
    if (strpos($_SERVER['REQUEST_URI'], '/?breakdance') !== false) {
        if (!bd_is_plugin_installed('Breakdance') || !bd_is_plugin_active_by_name('Breakdance')) return;

        wp_register_script('breakdance-hide-topbar-script', plugin_dir_url(__FILE__) . 'breakdance-hide-topbar-script.min.js', array('jquery'), '1.0', false);

        $options = get_option('bd_options');
        $load_sidebar = isset($options['load_sidebar']) ? $options['load_sidebar'] : 0;

        wp_localize_script('breakdance-hide-topbar-script', 'bdOptions', array('loadSidebar' => $load_sidebar));
        wp_enqueue_script('breakdance-hide-topbar-script');

        wp_deregister_script('jquery');  // Deregister WordPress jQuery
        wp_register_script('jquery', 'https://code.jquery.com/jquery-3.7.1.slim.min.js', array(), null, false);  // Register new jQuery and ensure it's printed in the <head>
        wp_enqueue_script('jquery');  // Enqueue the new jQuery
    }
}
add_action('wp_head', 'bd_add_jquery_and_custom_script_to_head');
